# UFA
Ultrametric Factor Analysis to detect hierarchies of nested latent factors underlying multidimensional phenomena. UFA is estimated via a cycling block coordinate descent algorithm.
